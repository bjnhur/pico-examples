**CycloneSSL is NOT supported for the Azure C shared utilities.**

The code here is provided for reference purposes.

A security audit is required if you attempt to bring this code back.