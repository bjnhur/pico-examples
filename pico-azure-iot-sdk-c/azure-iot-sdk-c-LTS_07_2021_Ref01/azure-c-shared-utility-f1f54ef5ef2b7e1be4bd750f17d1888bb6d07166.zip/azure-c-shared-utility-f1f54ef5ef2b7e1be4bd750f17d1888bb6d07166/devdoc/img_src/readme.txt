This directory contains the source files used to generate the image files in the sibling 'img' directory.
