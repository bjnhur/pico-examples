The images in this directory were generated from source files in the sibling 'img_src' directory.
