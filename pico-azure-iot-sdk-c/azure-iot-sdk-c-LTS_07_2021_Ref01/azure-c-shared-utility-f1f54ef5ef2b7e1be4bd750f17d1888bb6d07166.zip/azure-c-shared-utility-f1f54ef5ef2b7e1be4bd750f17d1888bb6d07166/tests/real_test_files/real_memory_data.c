// Copyright (c) Microsoft. All rights reserved.

#define GBALLOC_H

#include "real_memory_data_renames.h"

#include "../../src/memory_data.c"
