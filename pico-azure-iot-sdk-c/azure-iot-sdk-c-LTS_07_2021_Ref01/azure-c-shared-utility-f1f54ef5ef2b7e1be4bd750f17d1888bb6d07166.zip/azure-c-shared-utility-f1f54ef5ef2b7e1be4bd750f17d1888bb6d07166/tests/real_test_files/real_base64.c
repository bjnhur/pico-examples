// Copyright (c) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#define Azure_Base64_Encode real_Azure_Base64_Encode
#define Azure_Base64_Encode_Bytes real_Base64_Encode_Bytes
#define Azure_Base64_Decode real_Azure_Base64_Decode

#define GBALLOC_H

#include "azure_base64.c"
