This file is a convenience for debugging socket_async.c under Windows, and does not need to
normally be part of the SDK build.
